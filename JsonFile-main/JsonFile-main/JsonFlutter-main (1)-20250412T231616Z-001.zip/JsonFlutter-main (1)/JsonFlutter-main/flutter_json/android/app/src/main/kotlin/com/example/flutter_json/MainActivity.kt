package com.example.flutter_json

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
