// ignore_for_file: unnecessary_this

class Filme {
  late String titulo;
  late String lancamento;
  late String duracao;
  late String genero;
  late String diretor;
  late String atores;
  late String sinopse;

  Filme()
  {
    titulo = "";
    lancamento = "";
    duracao = "";
    genero = "";
    diretor = "";
    atores = "";
    sinopse = "";

  }

  Filme.v(this.titulo,this.lancamento, this.duracao, this.genero, this.diretor, this.atores, this.sinopse);

  

  Filme.fromJson(Map<String, dynamic> json)
      : titulo = json['Title'] as String,
        lancamento = json['Released'] as String,
        duracao = json['Runtime'] as String,
        genero = json['Genre'] as String,
        diretor = json['Director'] as String,
        atores = json['Actors'] as String,
        sinopse = json['Plot'] as String ;

  Map<String, dynamic> toJson() => {
        'Title': titulo,
        'Released': lancamento,
        'Runtime': duracao,
        'Genre': genero,
        'Director': diretor,
        'Actors': atores,
        'Plot': sinopse,
      };
}