

import 'package:flutter/material.dart';
import 'package:flutter_json/filme.dart';
// ignore: unused_import
import 'package:shake/shake.dart';
//import para usar o Random
import 'dart:math';
//import para usar o json
import 'dart:convert';

import 'package:flutter/services.dart';

void main() {
  runApp( const MaterialApp (title: "App",
      home: MainApp(),));
}

class MainApp extends StatefulWidget {
  const MainApp({super.key});


  @override
  MainAPP createState() => MainAPP();
}

class MainAPP extends State<MainApp> {
 // ignore: unused_field
 //late ShakeDetector _detector;
bool mostrarFilme = false;
List<Filme> filmes = List.empty();                                      
Filme filmeSorteado  = Filme();
int total = 0;
 Future<void> readJson() async {
    final String response = await rootBundle.loadString('assets/filmes.json');
     Iterable data = await json.decode(response);
    filmes =  List<Filme>.from(data.map((model)=> Filme.fromJson(model)));
    total = filmes.length;
    setState(() {
      filmes;
      total;
    });
  }


sorteiaFilme()
{
  var r = Random();
  var index = r.nextInt(filmes.length);
   filmeSorteado =  filmes[index];
   mostrarFilme = true;
  setState(() {
   filmeSorteado;
   mostrarFilme;}
  );

}


  @override
   initState()  {
    super.initState();
       readJson();

    //    _detector = ShakeDetector.autoStart(
      
    
    }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        extendBody: true,
        body:  Center(
          child:Padding(padding:const EdgeInsets.fromLTRB(25, 30, 25 , 30) ,
          child:Column(mainAxisSize: MainAxisSize.max,
           //Alinha no centro da página - vertical - , 
           //com distribuição uniforme
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children:<Widget>[ 
             Text('Sorteie um dos $total Filmes!', style: const TextStyle(color: Color.fromARGB(255, 92, 56, 190), fontSize: 40, fontStyle: FontStyle.italic),),
            
            
            ElevatedButton(onPressed:sorteiaFilme,style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 153, 134, 206),fixedSize: const Size(250, 75)), child: const Text("Sorteio!!!",style: TextStyle(color: Color.fromRGBO(73, 36, 62, 1),fontSize:30,fontWeight: FontWeight.bold),),),
           Visibility(
  visible: mostrarFilme,
  child:Expanded(child: Column( 
  
  mainAxisAlignment: MainAxisAlignment.spaceEvenly,mainAxisSize: MainAxisSize.max,
    children: <Widget>[
            Text(filmeSorteado.titulo,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:30, 
                                  fontWeight: FontWeight.w600),),
            Text(filmeSorteado.duracao,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w500),),
            Text(filmeSorteado.genero,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w500),),
            Text(filmeSorteado.lancamento,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w400),),
            Text(filmeSorteado.diretor,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w400),),

            Text(filmeSorteado.atores,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w400),),

            Text(filmeSorteado.sinopse,
                style: const TextStyle(color: Color.fromARGB(109, 13, 5, 90), 
                                  fontSize:25, 
                                  fontWeight: FontWeight.w400),),
           ])))

        ]
          )),
      ),
    ));
  }
}
